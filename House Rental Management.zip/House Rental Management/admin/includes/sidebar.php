<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
					
					<li><a href="#"><i class="fa fa-desktop"></i> House</a>
					<ul>
						<li><a href="create-room.php">Add a House</a></li>
						<li><a href="manage-rooms.php">Manage House</a></li>

					</ul>
				</li>

				<li><a href="manage-tenants.php"><i class="fa fa-users"></i>Manage Tenants</a></li>
				<li><a href="Manage-payment.php"><i class="fa fa-users"></i>Manage Payment</a></li>
				
				

			
		</nav>